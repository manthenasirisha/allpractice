// Author : Sirisha penmetsa
// Date : 21/03/2019
#include <iostream>
#include <string>

using namespace std;

int calculateTheSumOfDivisors(int);

string calculateThePositiveIntegerIsDeficientPerfectORabundant(int);

void calculateTheXnor(int, int);

int calculateTheReverseNumber(int);