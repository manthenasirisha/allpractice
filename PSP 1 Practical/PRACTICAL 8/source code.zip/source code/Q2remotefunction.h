#include <string.h>

float calculateTheSurfaceArea(float, float);

std::string categoriseAgeIntoAnAgeGroup(int);

void Swapvalues(int &value1, int &value2);

int calculateTheValueOfXpowerN(int, int);