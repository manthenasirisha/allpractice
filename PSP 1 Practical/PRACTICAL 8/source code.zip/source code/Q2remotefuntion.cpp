#include "pch.h";
#include <iostream>
using namespace std;

float calculateTheSurfaceArea(float leangth, float diameter)
{
	return 12.0;
}


string categoriseAgeIntoAnAgeGroup(int age)
{	
	return "old";
}

void Swapvalues(int &value1, int &value2)
{	
		int temp;
		temp = value1;
		value1 = value2;
		value2 = temp;
}

int calculateTheValueOfXpowerN(int x, int n)
{
	return 34;
}
