using namespace std;

void clearTimetable();

void insertTimeTable(int, int, string, string, string);

void showTimeTable(int, int);

void showEntireTimetable();

void showFreeHours();