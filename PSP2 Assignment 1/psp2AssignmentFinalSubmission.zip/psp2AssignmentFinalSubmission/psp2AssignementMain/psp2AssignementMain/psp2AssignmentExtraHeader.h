using namespace std;
#include <string>;

void clearTimetableTerm();

void insertTimeTableTerm(int, int, int, string, string, string);

void showTimeTableTerm(int, int, int);

void showEntireTimetableTerm();

void showFreeHoursTerm();