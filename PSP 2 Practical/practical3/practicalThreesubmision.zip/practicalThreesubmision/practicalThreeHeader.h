using namespace std;


void bubbleSortWithLowerNumberFromEnd(int A[], int );

void swap(int &a, int &b);

void bubbleSort(int A[], int );

void insertionSort(int A[], int );

void selectionSort(int A[], int);

void merge(int* Arr, int start, int mid, int end);

void mergeSort(int *Arr, int start, int end);

void display(int A[], int);