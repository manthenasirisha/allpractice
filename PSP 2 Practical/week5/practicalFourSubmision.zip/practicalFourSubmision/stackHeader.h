using namespace std;

void push(int);

int pop();

int isEmpty();

void display();

int peek();
