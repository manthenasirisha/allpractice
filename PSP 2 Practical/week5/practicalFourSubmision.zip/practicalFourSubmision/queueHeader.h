#include <iostream>
using namespace std;

void enQueue(int k);

int deQueue();
