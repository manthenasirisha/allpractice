using namespace std;

void appendNode(float);

void insertNode(float);

void updateNode(float,float);

void deleteNode(float);

void deleteAllNodes();

void findNode(float);

void printAllNodes();