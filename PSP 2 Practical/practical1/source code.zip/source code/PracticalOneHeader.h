#include "pch.h"


void displaymessage();

int compressDate(int, int, int);
int minimumNum(int, int, int);
int greatestnum(int, int, int);
bool isEven(int);
bool isPositive(int);
void drawpatternsOneA(int);
void drawpatternsTwoB(int);
void drawpatternsThreeC(int);
