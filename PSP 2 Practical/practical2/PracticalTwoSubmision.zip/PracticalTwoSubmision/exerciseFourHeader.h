#include <string>
using namespace std;

void insert(int value, int x, int y);

void display();
