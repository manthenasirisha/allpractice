// exercisefour.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include "exerciseFourHeader.h"
using namespace std;



int main()
{
	insert(30, 1, 1);

	insert(40, 2, 2);

	insert(50, 3, 3);


	display();

}

